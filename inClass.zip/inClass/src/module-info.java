/**
 * 
 */
/**
 * @author braed
 *
 */
module inClass {
}