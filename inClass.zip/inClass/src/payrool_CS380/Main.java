package payrool_CS380;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setFirstName("FirstName");
		employee.setLastName("LastName");
		employee.setRate(20);
		System.out.println(employee.toString());
	}

}
